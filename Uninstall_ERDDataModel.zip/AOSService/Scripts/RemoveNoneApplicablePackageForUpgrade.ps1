﻿
$blockListedPackage = (
"dynamicsax-appfoundationtestcommon",
"dynamicsax-appfoundationtestcommon-compile",
"dynamicsax-appfoundationtestcommon-develop",
"dynamicsax-appfoundationtestcommon-formadaptor",
"dynamicsax-application-applicationruntime",
"dynamicsax-applicationfoundation-compile",
"dynamicsax-applicationfoundation-develop",
"dynamicsax-applicationfoundation-formadaptor",
"dynamicsax-applicationfoundationformadaptor-compile",
"dynamicsax-applicationfoundationformadaptor-develop",
"dynamicsax-applicationfoundationformadaptor-formadaptor",
"dynamicsax-applicationfoundationunittests",
"dynamicsax-applicationfoundationunittests-compile",
"dynamicsax-applicationfoundationunittests-develop",
"dynamicsax-applicationfoundationunittests-formadaptor",
"dynamicsax-applicationplatform-compile",
"dynamicsax-applicationplatform-develop",
"dynamicsax-applicationplatform-formadaptor",
"dynamicsax-applicationplatformformadaptor-compile",
"dynamicsax-applicationplatformformadaptor-develop",
"dynamicsax-applicationplatformformadaptor-formadaptor",
"dynamicsax-applicationstaging",
"dynamicsax-applicationstaging-compile",
"dynamicsax-applicationstaging-develop",
"dynamicsax-applicationstagingformadaptor",
"dynamicsax-applicationstaging-formadaptor",
"dynamicsax-applicationstagingformadaptor-compile",
"dynamicsax-applicationstagingformadaptor-develop",
"dynamicsax-applicationstagingformadaptor-formadaptor",
"dynamicsax-applicationstagingtests",
"dynamicsax-applicationstagingtests-compile",
"dynamicsax-applicationstagingtests-develop",
"dynamicsax-applicationstagingtests-formadaptor",
"dynamicsax-applicationsuite-compile",
"dynamicsax-applicationsuite-develop",
"dynamicsax-applicationsuite-formadaptor",
"dynamicsax-applicationsuiteformadaptor-compile",
"dynamicsax-applicationsuiteformadaptor-develop",
"dynamicsax-applicationsuiteformadaptor-formadaptor",
"dynamicsax-applicationworkspaces-compile",
"dynamicsax-applicationworkspaces-develop",
"dynamicsax-applicationworkspacesformadaptor",
"dynamicsax-applicationworkspaces-formadaptor",
"dynamicsax-applicationworkspacesformadaptor-compile",
"dynamicsax-applicationworkspacesformadaptor-develop",
"dynamicsax-applicationworkspacesformadaptor-formadaptor",
"dynamicsax-applicationworkspacestests",
"dynamicsax-applicationworkspacestests-compile",
"dynamicsax-applicationworkspacestests-develop",
"dynamicsax-applicationworkspacestests-formadaptor",
"dynamicsax-appplatformtestcommon",
"dynamicsax-appplatformtestcommon-compile",
"dynamicsax-appplatformtestcommon-develop",
"dynamicsax-appplatformtestcommon-formadaptor",
"dynamicsax-appsuitetestcommon",
"dynamicsax-appsuitetestcommon-compile",
"dynamicsax-appsuitetestcommon-develop",
"dynamicsax-appsuitetestcommon-formadaptor",
"dynamicsax-budgetstaging",
"dynamicsax-budgetstaging-compile",
"dynamicsax-budgetstaging-develop",
"dynamicsax-budgetstagingformadaptor",
"dynamicsax-budgetstaging-formadaptor",
"dynamicsax-budgetstagingformadaptor-compile",
"dynamicsax-budgetstagingformadaptor-develop",
"dynamicsax-budgetstagingformadaptor-formadaptor",
"dynamicsax-budgetstagingtests",
"dynamicsax-budgetstagingtests-compile",
"dynamicsax-budgetstagingtests-develop",
"dynamicsax-budgetstagingtests-formadaptor",
"dynamicsax-calendar-compile",
"dynamicsax-calendar-develop",
"dynamicsax-calendarformadaptor",
"dynamicsax-calendar-formadaptor",
"dynamicsax-calendarformadaptor-compile",
"dynamicsax-calendarformadaptor-develop",
"dynamicsax-calendarformadaptor-formadaptor",
"dynamicsax-calendartests",
"dynamicsax-calendartests-compile",
"dynamicsax-calendartests-develop",
"dynamicsax-calendartests-formadaptor",
"dynamicsax-cirfoundationtests",
"dynamicsax-cirfoundationtests-compile",
"dynamicsax-cirfoundationtests-develop",
"dynamicsax-cirfoundationtests-formadaptor",
"dynamicsax-costaccounting",
"dynamicsax-costaccounting-compile",
"dynamicsax-costaccounting-develop",
"dynamicsax-costaccounting-formadaptor",
"dynamicsax-costaccountingformadaptor",
"dynamicsax-costaccountingformadaptor-compile",
"dynamicsax-costaccountingformadaptor-develop",
"dynamicsax-costaccountingformadaptor-formadaptor",
"dynamicsax-costaccountingtests",
"dynamicsax-costaccountingtests-compile",
"dynamicsax-costaccountingtests-develop",
"dynamicsax-costaccountingtests-formadaptor",
"dynamicsax-costaccountingax",
"dynamicsax-costaccountingax-compile",
"dynamicsax-costaccountingax-develop",
"dynamicsax-costaccountingax-formadaptor",
"dynamicsax-costaccountingaxformadaptor",
"dynamicsax-costaccountingaxformadaptor-compile",
"dynamicsax-costaccountingaxformadaptor-develop",
"dynamicsax-costaccountingaxformadaptor-formadaptor",
"dynamicsax-costaccountingaxtests",
"dynamicsax-costaccountingaxtests-compile",
"dynamicsax-costaccountingaxtests-develop",
"dynamicsax-costaccountingaxtests-formadaptor",
"dynamicsax-currency-compile",
"dynamicsax-currency-develop",
"dynamicsax-currencyformadaptor",
"dynamicsax-currency-formadaptor",
"dynamicsax-currencyformadaptor-compile",
"dynamicsax-currencyformadaptor-develop",
"dynamicsax-currencyformadaptor-formadaptor",
"dynamicsax-customeracceptancetests-compile",
"dynamicsax-customeracceptancetests-develop",
"dynamicsax-customeracceptancetests-formadaptor",
"dynamicsax-data-contoso",
"dynamicsax-data-demodata",
"dynamicsax-data-demovolumedata",
"dynamicsax-data-empty",
"dynamicsax-data-empty-platform",
"dynamicsax-dataimpexpapplication-compile",
"dynamicsax-dataimpexpapplication-develop",
"dynamicsax-dataimpexpapplication-formadaptor",
"dynamicsax-demodatasuite",
"dynamicsax-demodatasuite-compile",
"dynamicsax-demodatasuite-develop",
"dynamicsax-demodatasuite-formadaptor",
"dynamicsax-devtoolscustomizations",
"dynamicsax-devtoolscustomizations2",
"dynamicsax-devtoolscustomizations2-compile",
"dynamicsax-devtoolscustomizations2-develop",
"dynamicsax-devtoolscustomizations2-formadaptor",
"dynamicsax-devtoolscustomizations-compile",
"dynamicsax-devtoolscustomizations-develop",
"dynamicsax-devtoolscustomizations-formadaptor",
"dynamicsax-devtoolstestmodel",
"dynamicsax-devtoolstestmodel2",
"dynamicsax-devtoolstestmodel2-compile",
"dynamicsax-devtoolstestmodel2-develop",
"dynamicsax-devtoolstestmodel2-formadaptor",
"dynamicsax-devtoolstestmodel-compile",
"dynamicsax-devtoolstestmodel-develop",
"dynamicsax-devtoolstestmodel-formadaptor",
"dynamicsax-dimensions-compile",
"dynamicsax-dimensions-develop",
"dynamicsax-dimensionsformadaptor",
"dynamicsax-dimensions-formadaptor",
"dynamicsax-dimensionsformadaptor-compile",
"dynamicsax-dimensionsformadaptor-develop",
"dynamicsax-dimensionsformadaptor-formadaptor",
"dynamicsax-dimensionstestcommon",
"dynamicsax-dimensionstestcommon-compile",
"dynamicsax-dimensionstestcommon-develop",
"dynamicsax-dimensionstestcommon-formadaptor",
"dynamicsax-dimensionstests",
"dynamicsax-dimensionstests-compile",
"dynamicsax-dimensionstests-develop",
"dynamicsax-dimensionstests-formadaptor",
"dynamicsax-directory-compile",
"dynamicsax-directory-develop",
"dynamicsax-directory-formadaptor",
"dynamicsax-directoryformadaptor-compile",
"dynamicsax-directoryformadaptor-develop",
"dynamicsax-directoryformadaptor-formadaptor",
"dynamicsax-directorytests",
"dynamicsax-directorytests-compile",
"dynamicsax-directorytests-develop",
"dynamicsax-directorytests-formadaptor",
"dynamicsax-dispatchservice",
"dynamicsax-electronicreporting-compile",
"dynamicsax-electronicreporting-develop",
"dynamicsax-electronicreporting-formadaptor",
"dynamicsax-electronicreportingtestcommon",
"dynamicsax-electronicreportingtestcommon-compile",
"dynamicsax-electronicreportingtestcommon-develop",
"dynamicsax-electronicreportingtestcommon-formadaptor",
"dynamicsax-electronicreportingtests",
"dynamicsax-electronicreportingtests-compile",
"dynamicsax-electronicreportingtests-develop",
"dynamicsax-electronicreportingtests-formadaptor",
"dynamicsax-financialaccountingworkload",
"dynamicsax-financialaccountingworkload-compile",
"dynamicsax-financialaccountingworkload-develop",
"dynamicsax-financialaccountingworkload-formadaptor",
"dynamicsax-financialaccounting",
"dynamicsax-financialaccounting-compile",
"dynamicsax-financialaccounting-develop",
"dynamicsax-financialaccounting-formadaptor",
"dynamicsax-financialreportingadaptors",
"dynamicsax-financialreportingadaptors-compile",
"dynamicsax-financialreportingadaptors-develop",
"dynamicsax-financialreportingadaptors-formadaptor",
"dynamicsax-financialreporting-compile",
"dynamicsax-financialreporting-develop",
"dynamicsax-financialreporting-formadaptor",
"dynamicsax-financialreportingtestcommon",
"dynamicsax-financialreportingtestcommon-compile",
"dynamicsax-financialreportingtestcommon-develop",
"dynamicsax-financialreportingtestcommon-formadaptor",
"dynamicsax-financialreportingtests",
"dynamicsax-financialreportingtests-compile",
"dynamicsax-financialreportingtests-develop",
"dynamicsax-financialreportingtests-formadaptor",
"dynamicsax-fiscalbooks-compile",
"dynamicsax-fiscalbooks-develop",
"dynamicsax-fiscalbooksformadaptor",
"dynamicsax-fiscalbooks-formadaptor",
"dynamicsax-fiscalbooksformadaptor-compile",
"dynamicsax-fiscalbooksformadaptor-develop",
"dynamicsax-fiscalbooksformadaptor-formadaptor",
"dynamicsax-fiscalbookstests",
"dynamicsax-fiscalbookstests-compile",
"dynamicsax-fiscalbookstests-develop",
"dynamicsax-fiscalbookstests-formadaptor",
"dynamicsax-fleetmanagement-compile",
"dynamicsax-fleetmanagement-develop",
"dynamicsax-fleetmanagementextension-compile",
"dynamicsax-fleetmanagementextension-develop",
"dynamicsax-fleetmanagementextension-formadaptor",
"dynamicsax-fleetmanagement-formadaptor",
"dynamicsax-fleetmanagementunittests-compile",
"dynamicsax-fleetmanagementunittests-develop",
"dynamicsax-fleetmanagementunittests-formadaptor",
"dynamicsax-foundationtest",
"dynamicsax-foundationtestcommon",
"dynamicsax-foundationtestcommon-compile",
"dynamicsax-foundationtestcommon-develop",
"dynamicsax-foundationtestcommon-formadaptor",
"dynamicsax-foundationtest-compile",
"dynamicsax-foundationtest-develop",
"dynamicsax-foundationtest-formadaptor",
"dynamicsax-generalledger-compile",
"dynamicsax-generalledger-develop",
"dynamicsax-generalledgerformadaptor",
"dynamicsax-generalledger-formadaptor",
"dynamicsax-generalledgerformadaptor-compile",
"dynamicsax-generalledgerformadaptor-develop",
"dynamicsax-generalledgerformadaptor-formadaptor",
"dynamicsax-generalledgertests",
"dynamicsax-generalledgertests-compile",
"dynamicsax-generalledgertests-develop",
"dynamicsax-generalledgertests-formadaptor",
"dynamicsax-gfmtests",
"dynamicsax-gfmtests-compile",
"dynamicsax-gfmtests-develop",
"dynamicsax-gfmtests-formadaptor",
"dynamicsax-hcmtests",
"dynamicsax-hcmtests-compile",
"dynamicsax-hcmtests-develop",
"dynamicsax-hcmtests-formadaptor",
"dynamicsax-ledger-compile",
"dynamicsax-ledger-develop",
"dynamicsax-ledger-formadaptor",
"dynamicsax-ledgerformadaptor-compile",
"dynamicsax-ledgerformadaptor-develop",
"dynamicsax-ledgerformadaptor-formadaptor",
"dynamicsax-ledgertests",
"dynamicsax-ledgertests-compile",
"dynamicsax-ledgertests-develop",
"dynamicsax-ledgertests-formadaptor",
"dynamicsax-measurement-compile",
"dynamicsax-measurement-develop",
"dynamicsax-measurementformadaptor",
"dynamicsax-measurement-formadaptor",
"dynamicsax-measurementformadaptor-compile",
"dynamicsax-measurementformadaptor-develop",
"dynamicsax-measurementformadaptor-formadaptor",
"dynamicsax-measurementtests",
"dynamicsax-measurementtests-compile",
"dynamicsax-measurementtests-develop",
"dynamicsax-measurementtests-formadaptor",
"dynamicsax-meta-application-development",
"dynamicsax-meta-application-runtime",
"dynamicsax-meta-businessappplatform-development",
"dynamicsax-meta-businessappplatform-runtime",
"dynamicsax-meta-financialaccounting-development",
"dynamicsax-meta-financialaccounting-runtime",
"dynamicsax-meta-onebox-app-development",
"dynamicsax-meta-onebox-app-runtime",
"dynamicsax-meta-onebox-financialaccounting-development",
"dynamicsax-meta-onebox-financialaccounting-runtime",
"dynamicsax-meta-onebox-platform-development",
"dynamicsax-meta-onebox-platform-runtime",
"dynamicsax-meta-platform-development",
"dynamicsax-meta-platform-runtime",
"dynamicsax-OrchestrationPlugins",
"dynamicsax-organization-compile",
"dynamicsax-organization-develop",
"dynamicsax-organizationformadaptor",
"dynamicsax-organization-formadaptor",
"dynamicsax-organizationformadaptor-compile",
"dynamicsax-organizationformadaptor-develop",
"dynamicsax-organizationformadaptor-formadaptor",
"dynamicsax-organizationtests",
"dynamicsax-organizationtests-compile",
"dynamicsax-organizationtests-develop",
"dynamicsax-organizationtests-formadaptor",
"dynamicsax-payroll-compile",
"dynamicsax-payroll-develop",
"dynamicsax-payrollformadaptor",
"dynamicsax-payroll-formadaptor",
"dynamicsax-payrollformadaptor-compile",
"dynamicsax-payrollformadaptor-develop",
"dynamicsax-payrollformadaptor-formadaptor",
"dynamicsax-payrolltests",
"dynamicsax-payrolltests-compile",
"dynamicsax-payrolltests-develop",
"dynamicsax-payrolltests-formadaptor",
"dynamicsax-performancetest",
"dynamicsax-performancetest-compile",
"dynamicsax-performancetest-develop",
"dynamicsax-performancetest-formadaptor",
"dynamicsax-performancetool",
"dynamicsax-performancetool-compile",
"dynamicsax-performancetool-develop",
"dynamicsax-performancetool-formadaptor",
"dynamicsax-performancetoolunittests",
"dynamicsax-performancetoolunittests-compile",
"dynamicsax-performancetoolunittests-develop",
"dynamicsax-performancetoolunittests-formadaptor",
"dynamicsax-policy-compile",
"dynamicsax-policy-develop",
"dynamicsax-policyformadaptor",
"dynamicsax-policy-formadaptor",
"dynamicsax-policyformadaptor-compile",
"dynamicsax-policyformadaptor-develop",
"dynamicsax-policyformadaptor-formadaptor",
"dynamicsax-policytests",
"dynamicsax-policytests-compile",
"dynamicsax-policytests-develop",
"dynamicsax-policytests-formadaptor",
"dynamicsax-primitivetest",
"dynamicsax-primitivetest-compile",
"dynamicsax-primitivetest-develop",
"dynamicsax-primitivetest-formadaptor",
"dynamicsax-productconfiguration",
"dynamicsax-publicsector-compile",
"dynamicsax-publicsector-develop",
"dynamicsax-publicsectorformadaptor",
"dynamicsax-publicsector-formadaptor",
"dynamicsax-publicsectorformadaptor-compile",
"dynamicsax-publicsectorformadaptor-develop",
"dynamicsax-publicsectorformadaptor-formadaptor",
"dynamicsax-publicsectortests",
"dynamicsax-publicsectortests-compile",
"dynamicsax-publicsectortests-develop",
"dynamicsax-publicsectortests-formadaptor",
"dynamicsax-retailtests",
"dynamicsax-retailtests-compile",
"dynamicsax-retailtests-develop",
"dynamicsax-retailtests-formadaptor",
"dynamicsax-scmtests",
"dynamicsax-scmtests-compile",
"dynamicsax-scmtests-develop",
"dynamicsax-scmtests-formadaptor",
"dynamicsax-scmteststaging",
"dynamicsax-scmteststaging-compile",
"dynamicsax-scmteststaging-develop",
"dynamicsax-scmteststaging-formadaptor",
"dynamicsax-servertests",
"dynamicsax-servertests-compile",
"dynamicsax-servertests-develop",
"dynamicsax-servertests-formadaptor",
"dynamicsax-sitests",
"dynamicsax-sitests-compile",
"dynamicsax-sitests-develop",
"dynamicsax-sitests-formadaptor",
"dynamicsax-sourcedocumentation-compile",
"dynamicsax-sourcedocumentation-develop",
"dynamicsax-sourcedocumentationformadaptor",
"dynamicsax-sourcedocumentation-formadaptor",
"dynamicsax-sourcedocumentationformadaptor-compile",
"dynamicsax-sourcedocumentationformadaptor-develop",
"dynamicsax-sourcedocumentationformadaptor-formadaptor",
"dynamicsax-sourcedocumentationtypes-compile",
"dynamicsax-sourcedocumentationtypes-develop",
"dynamicsax-sourcedocumentationtypes-formadaptor",
"dynamicsax-sourcedocumentationtests",
"dynamicsax-sourcedocumentationtests-compile",
"dynamicsax-sourcedocumentationtests-develop",
"dynamicsax-sourcedocumentationtests-formadaptor",
"dynamicsax-subledger-compile",
"dynamicsax-subledger-develop",
"dynamicsax-subledgerformadaptor",
"dynamicsax-subledger-formadaptor",
"dynamicsax-subledgerformadaptor-compile",
"dynamicsax-subledgerformadaptor-develop",
"dynamicsax-subledgerformadaptor-formadaptor",
"dynamicsax-sysfake",
"dynamicsax-sysfake-compile",
"dynamicsax-sysfake-develop",
"dynamicsax-sysfake-formadaptor",
"dynamicsax-tax-compile",
"dynamicsax-tax-develop",
"dynamicsax-taxformadaptor",
"dynamicsax-tax-formadaptor",
"dynamicsax-taxformadaptor-compile",
"dynamicsax-taxformadaptor-develop",
"dynamicsax-taxformadaptor-formadaptor",
"dynamicsax-test",
"dynamicsax-test-compile",
"dynamicsax-test-develop",
"dynamicsax-testessentials-compile",
"dynamicsax-testessentials-develop",
"dynamicsax-testessentials-formadaptor",
"dynamicsax-test-formadaptor",
"dynamicsax-tutorial-compile",
"dynamicsax-tutorial-develop",
"dynamicsax-tutorial-formadaptor",
"dynamicsax-unitofmeasure-compile",
"dynamicsax-unitofmeasure-develop",
"dynamicsax-unitofmeasure-formadaptor",
"dynamicsax-unitofmeasureformadaptor-compile",
"dynamicsax-unitofmeasureformadaptor-develop",
"dynamicsax-unitofmeasureformadaptor-formadaptor",
"dynamicsax-unittests",
"dynamicsax-unittests-compile",
"dynamicsax-unittests-develop",
"dynamicsax-unittests-formadaptor",
"dynamicsax-upgrade",
"dynamicsax-upgrade-compile",
"dynamicsax-upgrade-develop",
"dynamicsax-upgrade-formadaptor")

$sourcePath = [IO.Path]::Combine($(split-Path -parent $PSScriptRoot), "Packages")
$files=get-childitem -Path:$sourcePath *.nupkg
foreach ($file in $files) 
{
    $fileName =  ($file.BaseName).Split(".")[0]
    if ($blockListedPackage -contains "$fileName")
    {
        write-output "Removing $file from packaging folder"
        remove-item $file.FullName
    }
}

# SIG # Begin signature block
# MIIntwYJKoZIhvcNAQcCoIInqDCCJ6QCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC8u6LYZSpJHT4/
# ga/LfkGNrpLG3Gc5/F+u7/pnwhnT3KCCDYEwggX/MIID56ADAgECAhMzAAACzI61
# lqa90clOAAAAAALMMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NjAxWhcNMjMwNTExMjA0NjAxWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCiTbHs68bADvNud97NzcdP0zh0mRr4VpDv68KobjQFybVAuVgiINf9aG2zQtWK
# No6+2X2Ix65KGcBXuZyEi0oBUAAGnIe5O5q/Y0Ij0WwDyMWaVad2Te4r1Eic3HWH
# UfiiNjF0ETHKg3qa7DCyUqwsR9q5SaXuHlYCwM+m59Nl3jKnYnKLLfzhl13wImV9
# DF8N76ANkRyK6BYoc9I6hHF2MCTQYWbQ4fXgzKhgzj4zeabWgfu+ZJCiFLkogvc0
# RVb0x3DtyxMbl/3e45Eu+sn/x6EVwbJZVvtQYcmdGF1yAYht+JnNmWwAxL8MgHMz
# xEcoY1Q1JtstiY3+u3ulGMvhAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUiLhHjTKWzIqVIp+sM2rOHH11rfQw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDcwNTI5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAeA8D
# sOAHS53MTIHYu8bbXrO6yQtRD6JfyMWeXaLu3Nc8PDnFc1efYq/F3MGx/aiwNbcs
# J2MU7BKNWTP5JQVBA2GNIeR3mScXqnOsv1XqXPvZeISDVWLaBQzceItdIwgo6B13
# vxlkkSYMvB0Dr3Yw7/W9U4Wk5K/RDOnIGvmKqKi3AwyxlV1mpefy729FKaWT7edB
# d3I4+hldMY8sdfDPjWRtJzjMjXZs41OUOwtHccPazjjC7KndzvZHx/0VWL8n0NT/
# 404vftnXKifMZkS4p2sB3oK+6kCcsyWsgS/3eYGw1Fe4MOnin1RhgrW1rHPODJTG
# AUOmW4wc3Q6KKr2zve7sMDZe9tfylonPwhk971rX8qGw6LkrGFv31IJeJSe/aUbG
# dUDPkbrABbVvPElgoj5eP3REqx5jdfkQw7tOdWkhn0jDUh2uQen9Atj3RkJyHuR0
# GUsJVMWFJdkIO/gFwzoOGlHNsmxvpANV86/1qgb1oZXdrURpzJp53MsDaBY/pxOc
# J0Cvg6uWs3kQWgKk5aBzvsX95BzdItHTpVMtVPW4q41XEvbFmUP1n6oL5rdNdrTM
# j/HXMRk1KCksax1Vxo3qv+13cCsZAaQNaIAvt5LvkshZkDZIP//0Hnq7NnWeYR3z
# 4oFiw9N2n3bb9baQWuWPswG0Dq9YT9kb+Cs4qIIwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIZjDCCGYgCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAsyOtZamvdHJTgAAAAACzDAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg9xNFJdbE
# QvAdJE59UaXIWKLz5fXEyDFpSAwCX0T+Uf4wQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQB52h4hK6zmH0y/TB1o2+Fn2+zaSDYMN9FCaPHd2Mnd
# roJGXELddMHYk9L53AXjd0dTFNz66Q47pgyxlcW5V8A2KJJ2uEkNcrg/p2hZyjKS
# C6S07FmmA2aubt7J9CDbITuiy25asFJxqAtshy6soFjCMUTVebSGDjYMFtMg88Ot
# gaRMDcaGkQoafbLxZuSuVZaCD9Ms75OcSYcQgz7u7mVz6Zq1ojYbcEtN5YrhayZk
# mD+YO4gJsXLeDhkVMdlOwN8OQLpTZlg6dISfVzT4Zf/AX6joeU0NncFXNxvuG27C
# QUs6mq+MnU8Yxj1WA8+IczRT9MfuBi+n7mE8FmtW2n2yoYIXFjCCFxIGCisGAQQB
# gjcDAwExghcCMIIW/gYJKoZIhvcNAQcCoIIW7zCCFusCAQMxDzANBglghkgBZQME
# AgEFADCCAVkGCyqGSIb3DQEJEAEEoIIBSASCAUQwggFAAgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIKCV3nTzP/jBobtw9+YFpeEpl8olKLlDWHyAUehF
# 5m1GAgZjEggFA3AYEzIwMjIwOTAzMjAyOTU0LjE1OFowBIACAfSggdikgdUwgdIx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1p
# Y3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046MDg0Mi00QkU2LUMyOUExJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFNlcnZpY2WgghFlMIIHFDCCBPygAwIBAgITMwAAAYdCFmYEXPP0
# jQABAAABhzANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMDAeFw0yMTEwMjgxOTI3MzlaFw0yMzAxMjYxOTI3MzlaMIHSMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOjA4NDItNEJFNi1DMjlBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNlMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvml4GWM9
# A6PREQiHgZAAPK6n+Th6m+LYwKYLaQFlZXbTqrodhsni7HVIRkqBFuG8og1KZry0
# 2xEmmbdp89O40xCIQfW8FKW7oO/lYYtUAQW2kp0uMuYEJ1XkZ6eHjcMuqEJwC47U
# akZx3AekakP+GfGuDDO9kZGQRe8IpiiJ4Qkn6mbDhbRpgcUOdsDzmNz6kXG7gfIf
# gcs5kzuKIP6nN4tsjPhyF58VU0ZfI0PSC+n5OX0hsU8heWe3pUiDr5gqP16a6kIj
# FJHkgNPYgMivGTQKcjNxNcXnnymT/JVuNs7Zvk1P5KWf8G1XG/MtZZ5/juqsg0Qo
# UmQZjVh0XRku7YpMpktW7XfFA3y+YJOG1pVzizB3PzJXUC8Ma8AUywtUuULWjYT5
# y7/EwwHWmn1RT0PhYp9kmpfS6HIYfEBboYUvULW2HnGNfx65f4Ukc7kgNSQbeAH6
# yjO5dg6MUwPfzo/rBdNaZfJxZ7RscTByTtlxblfUT46yPHCXACiX/BhaHEY4edFg
# p/cIb7XHFJbu4mNDAPzRlAkIj1SGuO9G4sbkjM9XpNMWglj2dC9QLN/0geBFXoNI
# 8F+HfHw4Jo+p6iSP8hn43mkkWKSGOiT4hLJzocErFntK5i9PebXSq2BvMgzVc+BB
# vCN35DfD0mokRKxam2tQM060SORy3S7ucesCAwEAAaOCATYwggEyMB0GA1UdDgQW
# BBQiUcAWukEtYYF+3WFzmZA/DaWNIDAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAx
# MCgxKS5jcmwwbAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3Rh
# bXAlMjBQQ0ElMjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4ICAQC5q35T2RKjAFRN/3cYjnPFztPa
# 7KeqJKJnKgviUj9IMfC8/FQ2ox6Uwyd40TS7zKvtuMl11FFlfWkEncN3lqihiSAq
# IDPOdVvr1oJY4NFQBOHzLpetepHnMg0UL2UXHzvjKg24VOIzb0dtdP69+QIy7SDp
# cVh9KI0EXKG2bolpBypqRttGTDd0JQkOtMdiSpaDpOHwgCMNXE8xIu48hiuT075o
# IqnHJha378/DpugI0DZjYcZH1cG84J06ucq5ygrod9szr19ObCZJdJLpyvJWCy8P
# RDAkRjPJglSmfn2UR0KvnoyCOzjszAwNCp/JJnkRp20weItzm97iNg+FZF1J9E16
# eWIB1sCr7Vj9QD6Kt+z81rOcLRfxhlO2/sK09Uw+DiQkPbu6OZ3TsDvLsr8yG9W2
# A8yXcggNqd4XpLtdEkf52OIN0GgRLSY1LNDB4IKY+Zj34IwMbDbs2sCig5Li2ILW
# EMV/6gyL37J71NbW7Vzo7fcGrNne9OqxgFC2WX5degxyJ3Sx2bKw6lbf04KaXnTB
# OSz0QC+RfJuz8nOpIf28+WmMPicX2l7gs/MrC5anmyK/nbeKkaOx+AXhwYLzETNg
# +1IcygjdwnbqWKafLdCNKfhsb/gM5SFbgD5ATEX1bAxwUFVxKvQv0dIRAm5aDjF3
# DZpgvy3mSojSrBN/8zCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUw
# DQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhv
# cml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg
# 4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aO
# RmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41
# JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5
# LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL
# 64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9
# QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj
# 0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqE
# UUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0
# kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435
# UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB
# 3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTE
# mr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwG
# A1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNV
# HSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNV
# HQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo
# 0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29m
# dC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5j
# cmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDAN
# BgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4
# sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th54
# 2DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRX
# ud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBew
# VIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0
# DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+Cljd
# QDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFr
# DZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFh
# bHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7n
# tdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+
# oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6Fw
# ZvKhggLUMIICPQIBATCCAQChgdikgdUwgdIxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MDg0Mi00QkU2
# LUMyOUExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoB
# ATAHBgUrDgMCGgMVAHh3k1QEKAZEhsLGYGHtf/6DG4PzoIGDMIGApH4wfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDmvdfuMCIY
# DzIwMjIwOTAzMjE0MTAyWhgPMjAyMjA5MDQyMTQxMDJaMHQwOgYKKwYBBAGEWQoE
# ATEsMCowCgIFAOa91+4CAQAwBwIBAAICFzEwBwIBAAICEXwwCgIFAOa/KW4CAQAw
# NgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgC
# AQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQBD5BL5bAY4jJJE+gZ2Q3LX1uv+IsRD
# nLDjPoKduiu4MFjsHf2ZLZz4qhEEXB4Hu/jSTDYFJIY7Lzlq/VmGzQtdzr35D0Yw
# WXR6AHUhG4CyqXJ2KZ3psmxSK0ttQM5nm4ZDD98/JQClv3UGossJ0HLM5d/kbIcy
# WUV+asLhqt6VJzGCBA0wggQJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwAhMzAAABh0IWZgRc8/SNAAEAAAGHMA0GCWCGSAFlAwQCAQUAoIIBSjAa
# BgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIIfXviAC
# zoEB910jKmGJIkSfI3VGiof5Oa8U3M5vBOJBMIH6BgsqhkiG9w0BCRACLzGB6jCB
# 5zCB5DCBvQQgxCzwoBNuoB92wsC2SxZhz4HVGyvCZnwYNuczpGyam1gwgZgwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAYdCFmYEXPP0jQAB
# AAABhzAiBCDERnZuim3bgyng9jVVg53LxRmo7G6JC4o0CxcPlcNfHzANBgkqhkiG
# 9w0BAQsFAASCAgCpghg3Qv+xPvQY2o5E9A61+H363G55B6QopZGij+WmiRlr/AAj
# BNXNXc4vgwV6IaLso7u3a7y2kCptPg6RqhHKmbDyRlnxbHpjEpqsZC7R8Ak+mE8N
# 9RCHpDiqElfVzgTVBhUkDEoT+1ix74ZBSAWtEUXhhJQ12iO3ckuVGqByXKVUKRno
# OFDWuNV1sxC6U8gE/b/8mwaUvEEp6rPuxmxnV9VnwecBp81D2CGdSLg8GOZYe/G9
# 6VBGiuB2cqpnMx/0eTNOjH/dG3i8JHyks8ZQykPYyGlaQ6Kht71OAv3ApUzNrxFN
# JP3TOptwj8hinUEuptzOsMQunB5FFoFMNTzv9Nn8APAtQsucOu/hLgzJmJmix0aA
# XGPo3ZJxQP2h1Tj86Q1BO5GZNd1p3jlTI4L2HMKfYHEyHwFPwj1teV+Lv6jj4rMq
# cCQuYMormqtaJG8iBDdc+RX1Z57hTze8nkRCr26mD9HARxDNuVbh0Kr2CXxo3lBO
# MLJr79yumgWW6WNq8dQdQ5U2PVnZIB/58798uqD0tPfl1YKDirzTwkTNANOb/Oqj
# 11zZBrXc4RjVyjmCoRGMF19XQzao3jczne6quSUfcfzDG9+d1uIJOeQAQw9P9qby
# jmwasqGd83ePY7jzc4/dzXeg/fUKYOCf9/1l8au2sgtMywzPXzxxA26zgg==
# SIG # End signature block
